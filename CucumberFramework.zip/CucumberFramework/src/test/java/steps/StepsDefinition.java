package steps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StepsDefinition extends BaseClass {

	@Given("Open the Chrome Browser")
	public void PreCondition() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	}

	@Given("Load the Application URL {string}")
	public void load_the_application_url(String url) {
		driver.get(url);
	}

	@Given("Enter the Username as {string}")
	public void EnterUserName(String UserName) {
		driver.findElement(By.id("username")).sendKeys(UserName);
	}

	@Given("Enter the Password as {string}")
	public void EnterPassword(String Password) {
		driver.findElement(By.id("password")).sendKeys(Password);
	}

	@When("Click the Login Button")
	public void ClickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("Homepage should be Displayed")
	public void VerifyHomePage() {
		Boolean HOmepage = driver.findElement(By.linkText("CRM/SFA")).isDisplayed();
		if (HOmepage) {
			System.out.println("Homepage is Displayed");
		} else {
			System.out.println("Not Dsiplayed");
		}
	}

	@Given("Click the {string} Menu Link")
	public void ClickLeadButton(String Link) {
		driver.findElement(By.linkText(Link)).click();

	}
	@Given("Enter the Company Name as{string}")
	public void enterthecompanyname(String CompanyName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(CompanyName);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
