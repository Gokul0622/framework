package Steps;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepsDefinition extends BaseClass {

	@Given("Enter the User Name as {string}")
	public void Username(String Username) {
		driver.findElement(By.xpath("(//input[@formcontrolname='email'])[1]")).sendKeys(Username);
		// String username =
		// driver.findElement(By.xpath("(//input[@formcontrolname='email'])[1]")).getText();
		System.out.println(" Username Entered Successfully ");
	}

	@Given("Enter the Password as {string}")
	public void Password(String Password) {
		driver.findElement(By.xpath("(//input[@formcontrolname='password'])[1]")).sendKeys(Password);
		// String password =
		// driver.findElement(By.xpath("(//input[@formcontrolname='password'])[1]")).getText();
		System.out.println(" Password Entered Successfully ");
	}

	@When("Click the Login Button")
	public void LoginButton() {
		driver.findElement(By.xpath("//div[@class='signin-btn']//button")).click();
		System.out.println(" Login Button clicked Successfully ");

	}

	@Then("ti_Spring Dashboard should be displayed")
	public void VerifyHomepage() {

		Boolean Displayed = driver.findElement(By.xpath("//h1[text()='Welcome to ti spring']")).isDisplayed();
		if (Displayed)
			System.out.println(" ti_Spring Homepage is displayed successfully ");
		else
			System.out.println("  ti_Spring Homepage is noy displayed Login failed ");

	}

	@When("Click the Profile Icon")
	public void ProfileIcon() throws InterruptedException {

		driver.findElement(By.xpath("(//img[@alt='profile image'])[1]")).click();
		System.out.println(" profile Icon is clicked is successfully ");

	}

	@When("Click the logout option")
	public void LogoutOption() {
		driver.findElement(
				By.xpath("//div[@class='section-dropdown']//a[@href='javascript:;'][normalize-space()='Logout']"))
				.click();
		System.out.println(" Logout Option Clicked Successfully ");

	}

	@Then("ti_Spring Login page should be displayed")
	public void LoginPage() {
		driver.findElement(By.xpath("//h1[.='Welcome to ti spring!']"));
		System.out.println(" ti_Spring Login Page is Displayed succesfully ");

	}

//	@But("Error message should be displayed")
//	public void ErrorMessage() {
//		System.out.println(" Error Message : Login failed :- Enter Valid Username and Password ");
//
//	}

}

//@Given("Open the Chrome Browser")
//public void OpenBrowser() {
//	WebDriverManager.chromedriver().setup();
//	driver = new ChromeDriver();
//	driver.manage().window().maximize();
//	driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
//
//}
//
//@Given("Enter the Application {string}")
//public void browserUrl(String url) {
//	driver.get(url);
//}
