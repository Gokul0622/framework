package Runner;

import Steps.BaseClass;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/test/java/feature/F01Login.feature", 
	glue = "Steps", 
	monochrome = true,
	publish = true,
	tags = "@Smoke")
public class CucumberRunner extends BaseClass {

}
