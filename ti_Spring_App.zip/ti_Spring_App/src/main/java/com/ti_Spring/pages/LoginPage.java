package com.ti_Spring.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	//ti_Spring User Name
	public LoginPage enterUsername(String data) {
		clearAndType(locateElement(Locators.XPATH, "(//input[@formcontrolname='email'])[1]"), data);
		reportStep(data+" Username entered successfully","pass");
		return this;
	}
	//ti_Spring Password
	public LoginPage enterPassword(String data) {
		clearAndType(locateElement(Locators.XPATH, "(//input[@formcontrolname='password'])[1]"), data);
		reportStep(data+" Password entered successfully","pass");
		return this;
	}
	
	// Click Login Button
	public HomePage LoginButton() throws InterruptedException {
		click(locateElement(Locators.XPATH, "//div[@class='signin-btn']//a[contains(text(),'Login')]"));
		reportStep("Login button clicked successfully", "pass");
		return new HomePage();
		
	}
}