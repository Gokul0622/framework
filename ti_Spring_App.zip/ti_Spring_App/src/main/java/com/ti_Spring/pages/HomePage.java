package com.ti_Spring.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {

	public HomePage verifyHomePage() {
		verifyDisplayed(locateElement(Locators.XPATH, "//h1[.='Welcome to ti spring']"));
		reportStep(" Welcome to ti spring is Displayed", "pass");
		return this;
	}

	public HomePage ClickProfileIcon() throws InterruptedException {

		Thread.sleep(2000);
		verifyDisplayed(locateElement(Locators.XPATH, "//label[@for='headerDropdown']//img[@alt='profile image']"));

		reportStep("Profile Icon is Clicked", "pass");
		return this;
	}

	public HomePage ClickLogout() throws InterruptedException {

		verifyDisplayed(locateElement(Locators.XPATH,
				"//div[@class='section-dropdown']//a[@href='javascript:;'][normalize-space()='Logout']"));
		reportStep("Logout Option is Clicked", "pass");
		return this;
	}
}
