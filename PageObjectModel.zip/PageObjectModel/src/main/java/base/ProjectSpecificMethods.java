package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.CreateLeadDataExcel;

public class ProjectSpecificMethods {
	public ChromeDriver driver;
	public static ExtentHtmlReporter reporter;
	public String fileName;
	public Properties Prop;
	public static ExtentTest test;
	public static ExtentReports extent;
	public String testname,testdescription,testauthor,testcategory;

	@BeforeSuite
	public void StartReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(false);
		extent = new ExtentReports();
		extent.attachReporter(reporter);

	}
@BeforeClass
	public void setTestcaseDetails() {
		test = extent.createTest(testname, testdescription);
		test.assignCategory(testcategory);
		test.assignAuthor(testauthor);
	}

	@DataProvider
	public String[][] sendData() throws IOException {
		return CreateLeadDataExcel.readData("Data");
	}

	@BeforeMethod
	public void Precondition() throws IOException {

		FileInputStream fis = new FileInputStream("./src/main/resources/englishconfig.properties");
		Prop = new Properties();
		Prop.load(fis);
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();

	}

	@AfterMethod
	public void PostDeclaration() {
		{
			driver.close();
		}
	}

	@AfterSuite
	public void stopReport() {
		extent.flush();

	}
}
