package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages_Create.LoginPage;

public class runVerifyLoginLogout extends ProjectSpecificMethods {
	@BeforeTest
	public void setTestDetails() {
		testname="Verify Login";
		testdescription="Verify the Login for Positive Scenario";
		testauthor ="Gokul"; 
		testcategory="smoke";
	}
	@Test(dataProvider="sendData")
	public void Logout() {
	
	
	new LoginPage(driver, Prop)
	.enterUsername("Demosalesmanager")
	.enterPassword("crmsfa")
	.clickLoginButton()
	.clickLogoutButton();
	
}
}