package Steps;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Stepdefinition {
	public ChromeDriver driver;

	@Given("Open the Chrome Browser")
	public void OpenBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);

	}

	@Given("Enter the Application {string}")
	public void browserUrl(String url) {
		driver.get(url);
	}

	@Given("Enter the User Name as {string}")
	public void Username(String Username) {
		driver.findElement(By.xpath("(//input[@formcontrolname='email'])[1]")).sendKeys(Username);
	}

	@Given("Enter the Password as {string}")
	public void Password(String Password) {
		driver.findElement(By.xpath("(//input[@formcontrolname='password'])[1]")).sendKeys(Password);
	}

	@When("Click the Login Button")
	public void LoginButton() {
		driver.findElement(By.xpath("//div[@class='signin-btn']")).click();
		// System.out.println("Home Page is displayed");

	}
	@Then("Home Page should be displayed")
	public void VerifyHomepage() {
		Boolean Displayed = driver.findElement(By.xpath("//a[text()='Home']")).isDisplayed();
		if(Displayed) {
		System.out.println(" ti_Spring Homepage is displayed ");
	}else {
		System.out.println(" ti_Spring Homepage is not displayed ");
	}

//	@But("Verify Displayed ErrorMessage")
//	public void ErrorMessage() {
//		driver.findElement(By.xpath("//a[text()='Home']")).click();
//	 System.out.println("Error Message is Displayed");
//
//	}

	@When("Close the Browser")
	public void closeTheBrowser() {
		driver.close();

//	@When("Click the crmsfa Link")
//	public void crmsfa() {
//		driver.findElement(By.linkText("CRM/SFA")).click();
//	}
//
//	@When("Click the Lead Menu")
//	public void LeadMenu() {
//		driver.findElement(By.linkText("Leads")).click();
//	}
//
//	@When("Click the Create Lead Menu")
//	public void createLeadMenu() {
//		driver.findElement(By.linkText("Create Lead")).click();
//	}
//
//	@Given("Enter the Company Name as {string}")
//	public void CompanyName(String CompanyName) {
//		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(CompanyName);
//	}
//
//	@Given("Enter the First Name as {string}")
//	public void firstName(String FirstName) {
//		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(FirstName);
//	}
//
//	@Given("Enter the Last Name as {string}")
//	public void LastName(String LastName) {
//		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(LastName);
//	}
//
//	@Given("Enter the Phno as {string}")
//	public void phno(String Phno) {
//		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(Phno);
//	}
//
//	@When("Click the createLead Button")
//	public void CreateLeadButton() {
//		driver.findElement(By.name("submitButton")).click();
//	}
//
//	@When("Click the Find Leads Menu")
//	public void click_the_find_leads_menu() {
//		driver.findElement(By.xpath("//a[normalize-space()='Find Leads']")).click();
//	}
//
//	@When("Click the Phone Menu")
//	public void click_the_phone_menu() {
//		driver.findElement(By.xpath("//span[text()='Phone']")).click();
//	}
//
//	@Given("Enter the PhoneNumber as {string}")
//	public void Phno(String Phno1) {
//		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(Phno1);
//	}
//
//	@When("Click the Find Leads Button")
//	public void click_the_findLeadsButton() {
//		driver.findElement(By.xpath("//button[normalize-space()='Find Leads']")).click();
//	}
//
//	// WebDriverWait wait = new WebDriverWait(driver,30);
//	@When("Click the Lead List")
//	public void clickTheLeadList() {
//		driver.findElement(By.xpath("//a[normalize-space()='10225']")).click();
//	}
//
//	@When("Click the Edit Menu")
//	public void click_the_edit_menu() {
//		driver.findElement(By.linkText("Edit")).click();
//	}
//
//	@Given("Clear the Company Name in the Field")
//	public void clear_the_company_name_in_the_field() {
//		driver.findElement(By.xpath("(//input[@name='companyName'])[2]")).clear();
//	}
//
//	@Given("Enter the Company name as {string}")
//	public void enter_the_company_name_as(String companyName) {
//		driver.findElement(By.id("updateLeadForm_companyName")).sendKeys(companyName);
//	}
//
//	@When("Click the Submit button")
//	public void click_the_submit_button() {
//		driver.findElement(By.name("submitButton")).click();
//	}

	}
}