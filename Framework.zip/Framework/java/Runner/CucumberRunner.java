package Runner;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="/Framework/java/Feature/Login.feature", glue="Steps", monochrome = true,publish = true)
public class CucumberRunner extends AbstractTestNGCucumberTests {

}

//src/test/java/Feature/Login.feature